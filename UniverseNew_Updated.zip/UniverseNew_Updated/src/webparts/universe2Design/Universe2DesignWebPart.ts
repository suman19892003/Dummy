import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import * as strings from 'Universe2DesignWebPartStrings';
import Universe2Design from './components/Universe2Design';
import { IUniverse2DesignProps } from './components/IUniverse2DesignProps';

import "../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import '../../../node_modules/bootstrap/dist/js/bootstrap.min.js';
import '../../../node_modules/popper.js/dist/popper.js';
import '../../../node_modules/bootstrap-daterangepicker/daterangepicker.css';
// import '../../../node_modules/
import { SPComponentLoader } from '@microsoft/sp-loader';

// SPComponentLoader.loadCss('https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css');
// SPComponentLoader.loadCss('https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css');
// SPComponentLoader.loadCss('https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css');
// SPComponentLoader.loadCss('https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css');

export interface IUniverse2DesignWebPartProps {
  description: string; 
}

export default class Universe2DesignWebPart extends BaseClientSideWebPart<IUniverse2DesignWebPartProps> {

  public render(): void {
    const element: React.ReactElement<IUniverse2DesignProps> = React.createElement(
      Universe2Design,
      {
        description: this.properties.description
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
