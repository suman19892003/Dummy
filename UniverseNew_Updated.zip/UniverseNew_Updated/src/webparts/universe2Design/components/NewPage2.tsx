import * as React from 'react';
export default class NewPage  extends React.Component {

    public render(): React.ReactElement {
    console.log('New page...!',this.props);
        return (
            <div>
                <p>Loans</p> 
            </div>
        );

    }
}