import * as React from 'react';
export default class Blog  extends React.Component {

    public render(): React.ReactElement {
    console.log('BLOG pages...!',this.props);
        return (
            <div>
                <p>Blog Us Component</p> 
            </div>
        );

    }
}