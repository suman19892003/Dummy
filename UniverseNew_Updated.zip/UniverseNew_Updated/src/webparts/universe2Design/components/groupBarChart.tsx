import * as React from 'react';
import { Bar } from 'react-chartjs-2';
import DateRangePicker from 'react-bootstrap-daterangepicker';
import "./styles/style.css";
const Path_5597: any = require('./images/Path5597.svg');
const Group_8579: any = require('./images/Group8579.svg');
export default class GroupBarChart extends React.Component {
    public data = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June'],
        datasets: [
            {
                label: 'Expenses',
                data: [12, 19, 3, 5, 2, 25],
                backgroundColor: 'rgb(236, 112, 6)',
            },
            {
                label: 'Revenue',
                data: [2, 3, 15, 5, 1, 4],
                backgroundColor: 'rgb(6, 56, 132)',
            },
        ],
    };


    public options = {
        scales: {
            yAxes: [
                {
                    ticks: {
                        beginAtZero: true,
                    },
                },
            ],
        },
    };
    public render(): React.ReactElement {
        return (
            <div>
                <div className="header-section mb-3">
                    <img src={Path_5597} />
                    <span className="header-title">Branch Financials</span>
                    {/* <span style={{ display: "block" }}>12 Month Trend (In Bn)</span> */}
                    <img className=" float-right" src={Group_8579} />
                </div>
                <div className="d-md-flex">
                    <div className="col-lg-6 col-md-12 col-sm-12">
                        <form>
                            <div className="form-group formData d-flex align-items-center mr-2">
                                <label className="mr-2 mb-0">DATE RANGE</label>
                                <DateRangePicker><input type="input" className="form-control" /></DateRangePicker>
                            </div>
                        </form>
                    </div>
                    <div className=" col-lg-5 col-md-12 col-sm-12 d-flex flex-wrap checkbox-section align-items-center">
                        <div className="custom-control custom-checkbox mb-2">
                            <input type="checkbox" className="custom-control-input" id="customCheck15" />
                            <label className="custom-control-label" htmlFor="customCheck15">Over All</label>
                        </div>
                        <div className="custom-control custom-checkbox mb-2">
                            <input type="checkbox" className="custom-control-input" id="customCheck16" />
                            <label className="custom-control-label" htmlFor="customCheck16">Zone Wise</label>
                        </div>

                    </div>
                </div>
                <p className="mb-1 font-weight-bold">Summary from Jan, 2021 - July, 2021</p>
                <div className="d-flex flex-wrap flex-sm-row shadow-none justify-content-between py-2">

                    <div className="d-flex flex-column">
                        <div className="text-left mb-1">
                            <span className="small">Total Branches</span>
                        </div>
                        <h4 className="m-0 font-weight-bold">36</h4>
                    </div>
                    <div className="d-flex flex-column">
                        <div className="mb-1">
                            <span className="small">Metro Branches</span>
                        </div>
                        <h4 className="m-0 font-weight-bold">22</h4>
                    </div>
                    <div className="d-flex flex-column">
                        <div className="mb-1">
                            <span className="small">Non-metro Branches</span>
                        </div>
                        <h4 className="m-0 font-weight-bold">14</h4>
                    </div>
                </div>
                <div className="d-flex flex-sm-row shadow-none py-2 mb-2">
                    <div className="d-flex flex-column w-50">
                        <div className="text-left mb-1">
                            <span className="small">Expenses</span>
                        </div>
                        <h4 className="m-0 font-weight-bold text-primary">&#8377; 76.27 Cr.</h4>
                    </div>
                    <div className="d-flex flex-column w-50">
                        <div className="mb-1">
                            <span className="small">Revenue</span>
                        </div>
                        <h4 className="m-0 font-weight-bold text-success">&#8593; 161.2 Cr.</h4>
                    </div>
                </div>
                <Bar data={this.data} options={this.options} ></Bar>
            </div >
        );

    }
}