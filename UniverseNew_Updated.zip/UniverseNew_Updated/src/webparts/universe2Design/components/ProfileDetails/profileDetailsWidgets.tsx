import * as React from 'react';
import { IUniverse2DesignProps } from '../IUniverse2DesignProps';
import styles from '../Universe2Design.module.scss';
import "../styles/style.css";
const Path_5597: any = require('../images/Path5597.svg');
const Group_8579: any = require('../images/Group8579.svg');
const Group_9: any = require('../images/MaskGroup9.png');
const nounForm_1236251: any = require('../images/noun_forms_1236251.svg');
const downloadingIcon: any = require('../images/downloadicon.jpg');
const noun_Products_1375585: any = require('../images/noun_products_1375585.svg');
const Group_8432: any = require('../images/Group8432.svg');
const Group_8598: any = require('../images/Group8598.svg');
const nounTickets_1532094: any = require('../images/noun_tickets_1532094.svg');
const noun_Confetti_1395941: any = require('../images/noun_Confetti_1395941.svg');
const birthday: any = require('../images/birthday1.jpg');
const iconDocuments: any = require('../images/icon-document-s.png');

export default class ProfileDetailsWidget extends React.Component<IUniverse2DesignProps, {}> {

    public render(): React.ReactElement<IUniverse2DesignProps> {
        return (
            <div className={styles.universe2Design}>
                {/* Home page social-media cards is started */}
                <div className="container">
                    <div className="row">
                        {/* Home page Teams chart card started */}
                        <div className=".col-xl-3 col-lg-3 col-md-6 col-sm-12 p-md-0 mt-4">
                            <div className="card team-chart ">
                                <div className="header-section mb-3">
                                    <img src={Path_5597} />
                                    <span className="header-title">Team Chart</span>
                                    <img className=" float-right" src={Group_8579} />
                                </div>
                                <div className="sub-head">
                                    <div className="sub-head-nav">
                                        <ul className="subNavLink">
                                            <li><a href="#">Team Chat<span className="badge notification1">20</span></a></li>
                                            <li><a href="#">Knowledge Bites<span className="badge notification2">10</span></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="scroll-custom card-data">
                                    <div className="card-body teams-chart-body mb-2" style={{ padding: "0px" }}>
                                        <div className="heading-section">
                                            <div className="profile-photo">
                                                <img src={Group_9} />
                                                <span className="dot aciveStatus"></span>
                                            </div>
                                            <div className="profile-details">
                                                <span className="profileName">Amrish Jain</span><br />
                                                <span className="profileDate">jan 12, 01:29 pm</span>
                                            </div>
                                            <br />
                                        </div>
                                        <div className="content-text">
                                            <p className="card-text-para">
                                                <span >Jeetesh </span>The policy for fund transfer online to overseas has been updated. Here’s the latest
                                                document
                                            </p>
                                        </div>
                                        <div className="footer-card">
                                            <img className="file-uploading" src={nounForm_1236251} />
                                            <span>funds transfer overseas.pdf</span>
                                            <img className="file-downolading" src={downloadingIcon} />
                                        </div>
                                        <br />
                                    </div>
                                    <div className="card-body teams-chart-body mb-2" style={{ padding: "0px" }}>
                                        <div className="heading-section">
                                            <div className="profile-photo">
                                                <img src={Group_9} />
                                                <span className="dot aciveStatus"></span>
                                            </div>
                                            <div className="profile-details">
                                                <span className="profileName">Amrish Jain</span><br />
                                                <span className="profileDate">jan 12, 01:29 pm</span>
                                            </div>
                                            <br />
                                        </div>
                                        <div className="content-text">
                                            <p className="card-text-para">
                                                <span >Jeetesh </span>The policy for fund transfer online to overseas has been updated. Here’s the latest
                                                document
                                            </p>
                                        </div>
                                        <div className="footer-card">
                                            <img className="file-uploading" src={nounForm_1236251} />
                                            <span>funds transfer overseas.pdf</span>
                                            <img className="file-downolading" src={downloadingIcon} />
                                        </div>
                                        <br />
                                    </div>
                                </div>
                                <div className="new-msg">
                                    <div className="card-header">
                                        <input type="text" placeholder="Type a new massage. Use @ to mention" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* Home page Teams chart card ended */}
                        {/* Home page MyProduct chart card started */}
                        <div className="col-lg-3 col-md-6 col-sm-12 co-xs-12 pr-md-0 mt-4">
                            <div className="card product-card mb-2">
                                <div className="header-section mb-3">
                                    <img src={noun_Products_1375585} />
                                    <span className="header-title">My Products(2)</span>
                                </div>
                                <div className="product-inside-card">
                                    <div className="card-body" >
                                        <div className="row">
                                            <div className="col-lg-2 col-md-2 col-sm-2 col-2 " style={{ padding: "0px" }} >
                                                <img src={Group_8432} />
                                            </div>
                                            <div className="col-lg-10 col-md-10 col-sm-10 col-10 ">
                                                <h6 className="card-title-heading">Credit Cards</h6>
                                                <p className="card-text-para">Credit Cards offer a host of benefits and offers to cater to your needs.</p>
                                                <a href="#" className="card-link">Know More</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div className="product-inside-card">
                                    <div className="card-body" >
                                        <div className="row">
                                            <div className="col-lg-2 col-md-2  col-sm-2 col-2 product-inside-card-img" style={{ padding: "0px" }}>
                                                <img src={Group_8598} />
                                            </div>
                                            <div className="col-lg-10 col-md-10 col-sm-10 col-10">
                                                <h6 className="card-title-heading">Forex Prepaid Cards</h6>
                                                <p className="card-text-para">Browse through our range of Forex Prepaid Cards You can also avoid the
                                                    effects of
                                                    currency</p>
                                                <a href="#" className="card-link">Know More</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* Home page MyProduct chart card started */}
                        {/* Home page MyTickets chart card started */}
                        <div className="col-lg-3 col-md-6 col-sm-12 co-xs-12 pr-md-0 mt-4">
                            <div className="card product-card mb-2 ">
                                <div className="header-section mb-3">
                                    <img src={nounTickets_1532094} />
                                    <span className="header-title">My Tickets (7)</span>
                                </div>
                                <div className="sub-head">
                                    <div className="sub-head-nav">
                                        <ul className="subNavLink">
                                            <li><a href="#">Pending<span className="badge notification2">20</span></a></li>
                                            <li><a href="#">Resolved<span className="badge notification1">10</span></a></li>
                                        </ul>
                                    </div>
                                </div>

                                <div className="sub-head">
                                    <div className="ticket-blog">
                                        <p className="ticket-slab">Printer is not connecting to laptop</p>
                                        <span className="ticket-slab-id">INC00122084</span>
                                        <span className="ticket-slab-days">1d ago</span>
                                    </div>
                                </div>

                                <div className="sub-head">
                                    <div className="ticket-blog">
                                        <p className="ticket-slab">Laptop is heating up frequently</p>
                                        <span className="ticket-slab-id">INC00322488</span>
                                        <span className="ticket-slab-days">2d ago</span>
                                    </div>
                                </div>

                                <div className="sub-head">
                                    <div className="ticket-blog">
                                        <p className="ticket-slab">New business cards</p>
                                        <span className="ticket-slab-id">INC00322488</span>
                                        <span className="ticket-slab-days">2d ago</span>
                                    </div>
                                </div>

                                <div className="sub-head">
                                    <div className="ticket-blog">
                                        <p className="ticket-slab">New business cards</p>
                                        <span className="ticket-slab-id">INC00322488</span>
                                        <span className="ticket-slab-days">2d ago</span>
                                    </div>
                                </div>

                                <div className="view-history">
                                    <a href="#">View all</a>
                                </div>

                            </div>
                        </div>
                        {/* Home page MyTickets chart card ended */}
                        {/* Home page Celebrations chart card Started */}
                        <div className="col-lg-3 col-md-6 col-sm-12 co-xs-12 mt-4">
                            <div className="card team-chart mb-2">
                                <div className="header-section mb-3">
                                    <img src={noun_Confetti_1395941} />
                                    <span className="header-title">Celebrations</span>
                                    <img className=" float-right" src={Group_8579} />
                                </div>
                                <div className="sub-head">
                                    <div className="sub-head-nav1">
                                        <ul className="subNavLink">
                                            <li><a href="#">Birthday<span className="badge  notification2">20</span></a></li>
                                            <li><a href="#">Aniversary<span className="badge  notification1">10</span></a></li>
                                            <li><a href="#">Recogtion<span className="badge notification1">10</span></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="date-card mt-2">
                                    <span>july 2021</span>
                                </div>
                                <div className="scroll-custom card-data">
                                    <div className=" cel-chart-body mb-2 mt-2" >
                                        <div className="heading-section mb-2">
                                            <div className="profile-photo1">
                                                <img src={Group_9} />
                                                <span className="dot aciveStatus"></span>
                                            </div>
                                            <div className="e-cards-title">
                                                <p>Anoop Soni</p>
                                                <span><img src={birthday} /> Today</span>
                                            </div>
                                            <div className="e-card-btn">
                                                <button type="button" className="btn btn-outline-primary">Send E-card</button>
                                            </div>
                                        </div>
                                    </div>

                                    <div className=" cel-chart-body mb-2" >
                                        <div className="heading-section mb-2">
                                            <div className="profile-photo1">
                                                <img src={Group_9} />
                                                <span className="dot aciveStatus"></span>
                                            </div>
                                            <div className="e-cards-title">
                                                <p>Anoop Soni</p>
                                                <span><img src={birthday} />Today</span>
                                            </div>
                                            <div className="e-card-btn">
                                                <button type="button" className="btn btn-outline-primary">Send E-card</button>
                                            </div>
                                        </div>
                                    </div>

                                    <div className=" cel-chart-body mb-2" >
                                        <div className="heading-section mb-2">
                                            <div className="profile-photo1">
                                                <img src={Group_9} />
                                                <span className="dot aciveStatus"></span>
                                            </div>
                                            <div className="e-cards-title">
                                                <p>Anoop Soni</p>
                                                <span><img src={birthday} />Today</span>
                                            </div>
                                            <div className="e-card-btn">
                                                <button type="button" className="btn btn-outline-primary">Send E-card</button>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            </div>
                        </div>
                        {/* Home page Celebrations chart card ended */}
                    </div>
                </div>
                {/* Home page social-media cards is ended */}
                {/* Team info is Started */}
                <div className="container">
                    <div className="row  mt-2">
                        {/* Team Celebrations cards is Started */}
                        <div className="col-lg-3 p-md-0">
                            <div className="TeamCelCard">
                                {/* <h4 className="headingTag">Team Celebrations</h4> */}
                                <div className="card team-chart mb-2 mt-2">
                                    <div className="header-section mb-3">
                                        <img src={noun_Confetti_1395941} />
                                        <span className="header-title">Celebrations</span>
                                        <img className=" float-right" src={Group_8579} />
                                    </div>
                                    <div className="sub-head">
                                        <div className="sub-head-nav1">
                                            <ul className="subNavLink">
                                                <li><a href="#">Birthday<span className="badge  notification2">20</span></a></li>
                                                <li><a href="#">Aniversary<span className="badge  notification1">10</span></a></li>
                                                <li><a href="#">Recogtion<span className="badge notification1">10</span></a></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <div className="scroll-custom card-data">
                                        <div className="date-card mt-2">
                                            <span>july 2021</span>
                                        </div>
                                        <div className=" cel-chart-body mb-2" >
                                            <div className="heading-section mb-2">
                                                <div className="profile-photo1">
                                                    <img src={Group_9} />
                                                    <span className="dot aciveStatus"></span>
                                                </div>
                                                <div className="e-cards-title">
                                                    <p>Anoop Soni</p>
                                                    <span><img src={birthday} /> July 5</span>
                                                </div>
                                                <div className="e-card-btn">
                                                    <button type="button" className="btn btn-outline-primary">Send E-card</button>
                                                </div>
                                            </div>
                                        </div>

                                        <div className=" cel-chart-body mb-2" >
                                            <div className="heading-section mb-2">
                                                <div className="profile-photo1">
                                                    <img src={Group_9} />
                                                    <span className="dot aciveStatus"></span>
                                                </div>
                                                <div className="e-cards-title">
                                                    <p>Anoop Soni</p>
                                                    <span><img src={birthday} />July 17</span>
                                                </div>
                                                <div className="e-card-btn">
                                                    <button type="button" className="btn btn-outline-primary">Send E-card</button>
                                                </div>
                                            </div>
                                        </div>

                                        <div className=" cel-chart-body mb-2" >
                                            <div className="heading-section mb-2">
                                                <div className="profile-photo1">
                                                    <img src={Group_9} />
                                                    <span className="dot aciveStatus"></span>
                                                </div>
                                                <div className="e-cards-title">
                                                    <p>Anoop Soni</p>
                                                    <span><img src={birthday} />July 26</span>
                                                </div>
                                                <div className="e-card-btn">
                                                    <button type="button" className="btn btn-outline-primary">Send E-card</button>
                                                </div>
                                            </div>
                                        </div>

                                        <div className="date-card mt-2">
                                            <span>Aug 2021</span>
                                        </div>
                                        <div className=" cel-chart-body mb-2" >
                                            <div className="heading-section mb-2">
                                                <div className="profile-photo1">
                                                    <img src={Group_9} />
                                                    <span className="dot aciveStatus"></span>
                                                </div>
                                                <div className="e-cards-title">
                                                    <p>Anoop Soni</p>
                                                    <span><img src={birthday} /> Aug 2</span>
                                                </div>
                                                <div className="e-card-btn">
                                                    <button type="button" className="btn btn-outline-primary">Send E-card</button>
                                                </div>
                                            </div>
                                        </div>

                                        <div className=" cel-chart-body mb-2" >
                                            <div className="heading-section mb-2">
                                                <div className="profile-photo1">
                                                    <img src={Group_9} />
                                                    <span className="dot aciveStatus"></span>
                                                </div>
                                                <div className="e-cards-title">
                                                    <p>Anoop Soni</p>
                                                    <span><img src={birthday} />Aug 9</span>
                                                </div>
                                                <div className="e-card-btn">
                                                    <button type="button" className="btn btn-outline-primary">Send E-card</button>
                                                </div>
                                            </div>
                                        </div>

                                        <div className=" cel-chart-body mb-2" >
                                            <div className="heading-section mb-2">
                                                <div className="profile-photo1">
                                                    <img src={Group_9} />
                                                    <span className="dot aciveStatus"></span>
                                                </div>
                                                <div className="e-cards-title">
                                                    <p>Anoop Soni</p>
                                                    <span><img src={birthday} />Aug 22</span>
                                                </div>
                                                <div className="e-card-btn">
                                                    <button type="button" className="btn btn-outline-primary">Send E-card</button>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* Team Celebrations cards is ended */} 
                        {/* Team details cards is Started */}
                        <div className="col-lg-3 pr-md-0">
                            <div className="TeamCelCard">
                                {/* <h4 className="headingTag">My Team (23)</h4> */}
                                <div className="card team-chart mb-2 mt-2">
                                    <div className="header-section mb-3">
                                        <img src={noun_Confetti_1395941} />
                                        <span className="header-title">My Team (23)</span>
                                        <img className=" float-right ml-2" src={Group_8579} />
                                    </div>
                                    <div className=" scroll-custom card-data ">
                                        <div className=" TeamCelCardBody clearfix" >
                                            <div className="heading-section mb-2">
                                                <div className="profile-photo">
                                                    <img src={Group_9} />
                                                    <span className="dot aciveStatus"></span>
                                                </div>
                                                <div className="profile-details1">
                                                    <p className="profileName">Ankur W</p>
                                                    <p className="profileDate1">On Leave Today</p>
                                                    <span className="mailIcon"><img src={Group_8579} />Send email</span>
                                                    <span className="chatIcon"><img src={Group_8579} />Start chat</span>
                                                </div>
                                                <div className="contactDetailsIcon">
                                                    <img src={iconDocuments} alt="contactDetails" />
                                                </div>
                                            </div>
                                        </div>
                                        <div className=" TeamCelCardBody clearfix" >
                                            <div className="heading-section mb-2">
                                                <div className="profile-photo">
                                                    <img src={Group_9} />
                                                    <span className="dot aciveStatus"></span>
                                                </div>
                                                <div className="profile-details1">
                                                    <p className="profileName">Ankur W</p>
                                                    <p className="profileDate">leave on 21/8</p>
                                                    <span className="mailIcon"><img src={Group_8579} />Send email</span>
                                                    <span className="chatIcon"><img src={Group_8579} />Start chat</span>
                                                </div>
                                                <div className="contactDetailsIcon">
                                                    <img src={iconDocuments} alt="contactDetails" />
                                                </div>
                                            </div>
                                        </div>

                                        <div className=" TeamCelCardBody clearfix" >
                                            <div className="heading-section mb-2">
                                                <div className="profile-photo">
                                                    <img src={Group_9} />
                                                    <span className="dot aciveStatus"></span>
                                                </div>
                                                <div className="profile-details1">
                                                    <p className="profileName">Ankur W</p>
                                                    <p className="profileDate">leave on 22/8</p>
                                                    <span className="mailIcon"><img src={Group_8579} />Send email</span>
                                                    <span className="chatIcon"><img src={Group_8579} />Start chat</span>
                                                </div>
                                                <div className="contactDetailsIcon">
                                                    <img src={iconDocuments} alt="contactDetails" />
                                                </div>
                                            </div>
                                        </div>
                                        <div className=" TeamCelCardBody clearfix" >
                                            <div className="heading-section mb-2">
                                                <div className="profile-photo">
                                                    <img src={Group_9} />
                                                    <span className="dot aciveStatus"></span>
                                                </div>
                                                <div className="profile-details1">
                                                    <p className="profileName">Ankur W</p>
                                                    <p className="profileDate">No leave from this month</p>
                                                    <span className="mailIcon"><img src={Group_8579} />Send email</span>
                                                    <span className="chatIcon"><img src={Group_8579} />Start chat</span>
                                                </div>
                                                <div className="contactDetailsIcon">
                                                    <img src={iconDocuments} alt="contactDetails" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* Team details cards is ended */}
                        {/* Social comm & knowledge sharing cards is Started */}
                        <div className="col-lg-3 pr-md-0">
                            <div className="card team-chart  mt-2">
                                <div className="header-section mb-3">
                                    <img src={Path_5597} />
                                    <span className="header-title">Team Chart</span>
                                    <img className=" float-right" src={Group_8579} />
                                </div>
                                <div className="sub-head">
                                    <div className="sub-head-nav">
                                        <ul className="subNavLink">
                                            <li><a href="#">Team Chat<span className="badge notification1">20</span></a></li>
                                            <li><a href="#">Knowledge Bites<span className="badge notification2">10</span></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="scroll-custom card-data">

                                    <div className=" TeamCelCardBody1 clearfix" >
                                        <div className="heading-section mb-2 mt-2 clearfix">
                                            <div className="profilePhoto">
                                                <img src={Group_9} />
                                                <span className="dot1 aciveStatus3"></span>
                                            </div>
                                            <div className="profileName1">
                                                <p>Ankur Wadhva</p>
                                            </div>
                                        </div>
                                        <div className="heading-section mb-2 mt-2 clearfix">
                                            <div className="profilePhoto">
                                                <img src={Group_9} />
                                                <span className="dot1 aciveStatus3"></span>
                                            </div>
                                            <div className="profileName1">
                                                <p>Dnyaneshwar Gaikhe</p>
                                            </div>
                                        </div>
                                        <div className="heading-section mb-2 mt-2 clearfix">
                                            <div className="profilePhoto">
                                                <img src={Group_9} />
                                                <span className="dot1 aciveStatus3"></span>
                                            </div>
                                            <div className="profileName1">
                                                <p>Abhishiktha Sarella</p>
                                            </div>
                                        </div>
                                        <div className="heading-section mb-2 mt-2 clearfix">
                                            <div className="profilePhoto">
                                                <img src={Group_9} />
                                                <span className="dot1 aciveStatus3"></span>
                                            </div>
                                            <div className="profileName1">
                                                <p>Prateeh Khanna</p>
                                            </div>
                                        </div>
                                        <div className="heading-section mb-2 mt-2 clearfix">
                                            <div className="profilePhoto">
                                                <img src={Group_9} />
                                                <span className="dot1 aciveStatus3"></span>
                                            </div>
                                            <div className="profileName1">
                                                <p>Vishal Agarwal</p>
                                            </div>
                                        </div>
                                        <div className="heading-section mb-2 mt-2 clearfix">
                                            <div className="profilePhoto">
                                                <img src={Group_9} />
                                                <span className="dot1 aciveStatus3"></span>
                                            </div>
                                            <div className="profileName1">
                                                <p>Ankur Wadhva</p>
                                            </div>
                                        </div>
                                        <div className="heading-section mb-2 mt-2 clearfix">
                                            <div className="profilePhoto">
                                                <img src={Group_9} />
                                                <span className="dot1 aciveStatus3"></span>
                                            </div>
                                            <div className="profileName1">
                                                <p>Ankur Wadhva</p>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div className="new-msg">
                                    <div className="card-header">
                                        <input type="text" placeholder="Type a new massage. Use @ to mention" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-lg-3 ">
                            {/* <h4>Social comm and knowledge sharing</h4> */}
                            <div className="card team-chart  mt-2">
                                <div className="header-section mb-3">
                                    <img src={Path_5597} />
                                    <span className="header-title">Team Chart</span>
                                    <img className=" float-right" src={Group_8579} />
                                </div>
                                <div className="sub-head">
                                    <div className="sub-head-nav">
                                        <ul className="subNavLink">
                                            <li><a href="#">Team Chat<span className="badge notification1">20</span></a></li>
                                            <li><a href="#">Knowledge Bites<span className="badge notification2">10</span></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="scroll-custom card-data">
                                    <div className="card-body teams-chart-body mb-2" style={{ padding: "0px" }}>
                                        <div className="heading-section">
                                            <div className="profile-photo">
                                                <img src={Group_9} />
                                                <span className="dot aciveStatus"></span>
                                            </div>
                                            <div className="profile-details">
                                                <span className="profileName">Amrish Jain</span><br />
                                                <span className="profileDate">jan 12, 01:29 pm</span>
                                            </div>
                                            <br />
                                        </div>
                                        <div className="content-text">
                                            <p className="card-text-para">
                                                <span >Jeetesh </span>The policy for fund transfer online to overseas has been updated. Here’s the latest
                                                document
                                            </p>
                                        </div>
                                        <div className="footer-card">
                                            <img className="file-uploading" src={nounForm_1236251} />
                                            <span>funds transfer overseas.pdf</span>
                                            <img className="file-downolading" src={downloadingIcon} />
                                        </div>
                                        <br />
                                    </div>
                                    <div className="card-body teams-chart-body mb-2" style={{ padding: "0px" }}>
                                        <div className="heading-section">
                                            <div className="profile-photo">
                                                <img src={Group_9} />
                                                <span className="dot aciveStatus"></span>
                                            </div>
                                            <div className="profile-details">
                                                <span className="profileName">Amrish Jain</span><br />
                                                <span className="profileDate">jan 12, 01:29 pm</span>
                                            </div>
                                            <br />
                                        </div>
                                        <div className="content-text">
                                            <p className="card-text-para">
                                                <span >Jeetesh </span>The policy for fund transfer online to overseas has been updated. Here’s the latest
                                                document
                                            </p>
                                        </div>
                                        <div className="footer-card">
                                            <img className="file-uploading" src={nounForm_1236251} alt = "file-uploading"/>
                                            <span>funds transfer overseas.pdf</span>
                                            <img className="file-downolading" src={downloadingIcon} alt = "file-downolading"/>
                                        </div>
                                        <br />
                                    </div>
                                </div>
                                <div className="new-msg">
                                    <div className="card-header">
                                        <input type="text" placeholder="Type a new massage. Use @ to mention" />
                                    </div>
                                </div>
                            </div>
                        </div>
                        {/* Social comm & knowledge sharing cards is ended */}
                    </div>
                </div>
                {/* Teams Info widgets cards ended */}
            </div>
        );

    }
}