import * as React from 'react';
import styles from './Universe2Design.module.scss';
import { IUniverse2DesignProps } from './IUniverse2DesignProps';
import { Route, Link, Switch,HashRouter } from 'react-router-dom';
import Home from './Home';
import Blog from './Blog';
import './styles/style.css';
import NewPage from './NewPage';
import NewPage2 from './NewPage2';
// import '../../../../node_modules/rsuite/dist/styles/rsuite-default.css';
const icici: any = require('./images/icici.jpg');
const searchIcon: any = require('./images/search-24px.svg');
const notifications: any = require('./images/notifications_none-24px(1).svg');
const account: any = require('./images/account_circle-24px.svg');

export default class Universe2Design extends React.Component<IUniverse2DesignProps, {}> {
  public render(): React.ReactElement<IUniverse2DesignProps> {
    return (
      <div className={ styles.universe2Design }>
        {/* <Home description = {this.props.description}></Home> */}
        {/* <HashRouter> 
          <Switch> 
            <Route sensitive exact path="/"  component={Home}></Route> 
            <Route path="/blog"  component={Blog}></Route>  
          </Switch>   
        </HashRouter> */}  
        {/* <!-- Header --> */} 
        <div className="header">
          <div className="row">      
            <div className="col-lg-3 col-md-12 col-sm-12 col-xs-12 " >
              <img className="image" src={icici}></img>
            </div>
            <div className=" col-lg-5 col-md-12 col-sm-12 col-xs-12 searchCriteria">
              <img src={searchIcon}></img>
              <input className="form-control search-box mt-0" type="text" placeholder="What are you looking for? " aria-label="Search" />
            </div>

            <div className="col-lg-3 col-md-12 col-sm-12 col-xs-12 dateTime ">
              <span >Mon 28 Jun</span><br />
              <span>2:30pm</span>
            </div>
            <div className="col-lg-1 col-md-12 col-sm-12 col-xs-12 notification-icons">
              <img className="notify" src={notifications} ></img>
              <span className="notificationIcon"></span>
              <img className="account" src={account} ></img>
            </div>
          </div> 
        </div> 
        {/* <!-- Navbar --> */}
        <HashRouter>
          <nav className="navbar navbar-expand-lg navbar-light  nav">
            <a className="navbar-brand" href="#"></a>
            <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span className="navbar-toggler-icon"></span>
            </button>

            <div className="collapse navbar-collapse " id="navbarSupportedContent">
              <ul className="navbar-nav subNavLink mr-auto">
                <li className="nav-item  ">
                  <Link to={'/'} className=" items"> Home </Link>
                </li>
                <li className="nav-item dropdown ">
                  <a className=" items dropdown-toggle " href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    All Products
                  </a>
                  <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a className="sub-item items " href="#">Option 1</a>
                    <a className="sub-item items " href="#">Option 2</a>
                    <a className="sub-item items" href="#">Option 3</a>
                  </div>
                </li>
                <li className="nav-item dropdown ">
                  <a className="  dropdown-toggle items " href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Business Groups
                  </a>
                  <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a className="sub-item items" href="#">Option 1</a>
                    <a className="sub-item items " href="#">Option 2</a>
                    <a className="sub-item items" href="#">Option 3</a>
                  </div>
                </li>
                <li className="nav-item dropdown ">
                  <a className="  dropdown-toggle items " href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    My Docs
                  </a>
                  <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a className="sub-item items" href="#">Option 1</a>
                    <a className="sub-item items" href="#">Option 2</a>
                    <a className="sub-item items" href="#">Option 3</a>
                  </div>
                </li>
                <li className="nav-item dropdown ">
                  <a className="  dropdown-toggle items" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Know Your Bank
                  </a>
                  <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a className="sub-item items" href="#">Option 1</a>
                    <a className="sub-item items" href="#">Option 2</a>
                    <a className="sub-item items" href="#">Option 3</a>
                  </div>
                </li>
                <li className="nav-item dropdown ">
                  <a className=" dropdown-toggle items" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    HRMS
                  </a>
                  <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a className="sub-item items " href="#">Option 1</a>
                    <a className="sub-item items " href="#">Option 2</a>
                    <a className="sub-item items" href="#">Option 3</a>
                  </div>
                </li>
                <li className="nav-item  ">
                  <Link className=" items" to={"/blog"}>Blogs</Link>
                </li>
              </ul>
            </div>
          </nav>
          <Switch>
            <Route sensitive exact path="/" component={Home} />
            <Route path="/blog" component={Blog} />
            <Route path="/NewPage" component={NewPage}/>
            <Route path="/NewPage2" component={NewPage2}/>
          </Switch>
        </HashRouter>
      </div>
    );
  }
}
