/* tslint:disable */
require("./Universe2Design.module.css");
const styles = {
  universe2Design: 'universe2Design_19062d34',
  container: 'container_19062d34',
  row: 'row_19062d34',
  column: 'column_19062d34',
  'ms-Grid': 'ms-Grid_19062d34',
  title: 'title_19062d34',
  subTitle: 'subTitle_19062d34',
  description: 'description_19062d34',
  button: 'button_19062d34',
  label: 'label_19062d34'
};

export default styles;
/* tslint:enable */