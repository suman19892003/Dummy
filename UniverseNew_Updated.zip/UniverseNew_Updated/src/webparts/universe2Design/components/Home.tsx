import * as React from 'react';
import styles from './Universe2Design.module.scss';
import { IUniverse2DesignProps } from './IUniverse2DesignProps';
import "./universeStyle.css";
import './styles/Navbar.css';
import $ from 'jquery';
import "./styles/style.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { faChevronRight } from '@fortawesome/free-solid-svg-icons'
import InstagramEmbed from 'react-instagram-embed'
import { Timeline } from 'react-twitter-widgets';
// import { DateRangePicker } from 'rsuite';
import ReactEcharts from 'echarts-for-react';
import ProfileDetailsWidget from './ProfileDetails/profileDetailsWidgets';
import GroupBarChart from './groupBarChart';
import GroupChart from './groupChart';
import Iframe from 'react-iframe';
import DateRangePicker from 'react-bootstrap-daterangepicker';
import { Route, Link, Switch, HashRouter } from 'react-router-dom';
// import {DatePicker} from 'react-bootstrap-date-picker'
const searchIcon: any = require('./images/search-24px.svg');
const iView: any = require('./images/iview.svg');
const travelClaims: any = require('./images/travel-claims.svg');
const eForms: any = require('./images/e-forms.svg');
const e_circular: any = require('./images/e-circulars.svg');
const add: any = require('./images/add.svg');
const moreLinks: any = require('./images/more-links.svg');
const iconAnnouncement: any = require('./images/icon-announcement.png');
const iconApproval: any = require('./images/icon-approval.svg');
const iconDocument: any = require('./images/icon-document.svg');
const iconDocuments: any = require('./images/icon-document-s.png');
const iconShare: any = require('./images/icon-share.png');
const Path_5597: any = require('./images/Path5597.svg');
const Group_8579: any = require('./images/Group8579.svg');
const Group_9: any = require('./images/MaskGroup9.png');
const downloadingIcon: any = require('./images/downloadicon.jpg');
const ICICI_Mobile_app: any = require('./images/icici_mobile_app.jpg');
const Resolution_Covid: any = require('./images/house.jpg');
const ICICI_PhonePay: any = require('./images/ICICI_PhonePay.jpg');
const map: any = require('./images/map.png');
const img_square: any = require('./images/img_square.png');
const sample_card: any = require('./images/sample_card.jpg');

export default class Home extends React.Component<IUniverse2DesignProps, {}> {


    public componentDidMount() {
        $(function () {
            $("ul.subNavLink li").click(function () {
                $("ul.subNavLink li").removeClass("active");
                $(this).addClass("active");
            });
            $("ul.subNavLinkProducts li").click(function () {
                $("ul.subNavLinkProducts li").removeClass("active");
                $(this).addClass("active");
            });

        });

        $('#myTab a').on('click', function (event) {
            event.preventDefault()
            $(this).tab('show')
        })

        $(document).ready(function () {
            setTimeout(function () {
                console.log("das");
                $('#twitter-widget-0').contents().find('.timeline-Tweet .timeline-Tweet-action').hide();
                $('#twitter-widget-0').contents().find('.timeline-ShowMoreButton').addClass('loadmore-custom');
            }, 8000);

            setInterval(function () {
                $('#twitter-widget-0').contents().find('.timeline-Tweet .timeline-Tweet-action').hide();
            }, 1000);

        });

        const script = document.createElement("script");

        script.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v12.0";
        script.async = true;

        document.body.appendChild(script);
    }
    public render(): React.ReactElement<IUniverse2DesignProps> {
        return (
            <div className={styles.universe2Design}>
                <div className="container mt-5 text-left">
                    <div className="row">
                        <div className="col-md-8 col-sm-12 p-md-0">
                            <div className="cards-section d-sm-flex justify-content-around">
                                <div className="card">
                                    <div className="card-body text-center d-flex flex-column justify-content-center align-items-center">
                                        <img src={iView} alt="iview" />
                                        <p className="font-weight-bold">iView</p>
                                    </div>
                                </div>
                                <div className="card">
                                    <div className="card-body text-center d-flex flex-column justify-content-center align-items-center">
                                        <img src={travelClaims} alt="iview" />
                                        <p className="font-weight-bold">Travel Claims</p>
                                    </div>
                                </div>
                                <div className="card">
                                    <div className="card-body text-center d-flex flex-column justify-content-center align-items-center">
                                        <img src={eForms} alt="iview" />
                                        <p className="font-weight-bold">E-Forms</p>
                                    </div>
                                </div>
                                <div className="card">
                                    <div className="card-body text-center d-flex flex-column justify-content-center align-items-center">
                                        <img src={e_circular} alt="iview" />
                                        <p className="font-weight-bold">E-Circulars</p>
                                    </div>
                                </div>
                                <div className="card">
                                    <div className="card-body text-center d-flex flex-column justify-content-center align-items-center">
                                        <img src={add} alt="iview" />
                                        <p className="font-weight-bold">Add</p>
                                    </div>
                                </div>
                                <div className="card">
                                    <div className="card-body text-center d-flex flex-column justify-content-center align-items-center">
                                        <img src={add} alt="iview" />
                                        <p className="font-weight-bold">Add</p>
                                    </div>
                                </div>
                                <div className="card">
                                    <div className="card-body text-center d-flex flex-column justify-content-center align-items-center">
                                        <img src={moreLinks} alt="iview" />
                                        <p className="font-weight-bold">More Links</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4 col-sm-12">
                            <div className="survey-section position-relative text-white rounded">
                                <p className="mb-2">Last reminder to complete ICICI Bank<br /> Universe user experience survey</p>
                                <button type="button" className="btn btn-success">Complete now</button>
                                <img src={iconAnnouncement} className="right-section position-absolute" alt="share" />
                            </div>
                        </div>


                        <div className="col-md-6 col-sm-12 mt-4 p-md-0">
                            <div id="slider" className="carousel slide" data-ride="carousel">
                                <ol className="carousel-indicators">
                                    <li data-target="#slider" data-slide-to="0" className="active"></li>
                                    <li data-target="#slider" data-slide-to="1"></li>
                                    <li data-target="#slider" data-slide-to="2"></li>
                                </ol>
                                <div className="carousel-inner">
                                    <div className="carousel-item active">
                                        <div className="carousel-caption d-block text-left">
                                            <h6>Town Hall Announcements</h6>
                                            <h1>ICICI Bank and PhonePe Partner to issue FASTag</h1>
                                            <h5>PhonePe users would now get a fully digitised experience; wouldn't have to visit physical stores, toll locations to buy a FASTag</h5>
                                            <button type="button" className="btn px-4 text-white mt-3">Know more</button>
                                        </div>
                                    </div>
                                    <div className="carousel-item">
                                        <div className="carousel-caption d-block text-left">
                                            <h6>Town Hall Announcements 2</h6>
                                            <h1>ICICI Bank Example 2 to issue FASTag 2</h1>
                                            <h5>PhonePe users would now get a fully digitised experience; wouldn't have to visit physical stores, toll locations to buy a FASTag 2</h5>
                                            <button type="button" className="btn px-4 text-white mt-3">Know more</button>
                                        </div>
                                    </div>
                                    <div className="carousel-item">
                                        <div className="carousel-caption d-block text-left">
                                            <h6>Town Hall Announcements 3</h6>
                                            <h1>ICICI Bank Example 3 to issue FASTag 3</h1>
                                            <h5>PhonePe users would now get a fully digitised experience; wouldn't have to visit physical stores, toll locations to buy a FASTag 3</h5>
                                            <button type="button" className="btn px-4 text-white mt-3">Know more</button>
                                        </div>
                                    </div>
                                </div>
                                <img src={iconAnnouncement} className="right-section position-absolute" alt="share" />
                            </div>
                        </div>

                        <div className="col-md-3 col-sm-12 mt-4 pr-md-0">
                            <div className="card rounded p-3 my-approvals fix-height">
                                <div className="title mb-2 d-flex align-items-center">
                                    <div className="d-flex rounded-circle circle-bg mr-2 justify-content-center align-items-center">
                                        <img src={iconApproval} alt="approval" />
                                    </div>
                                    <h6 className="mb-1 font-weight-bold">My Approvals (28)</h6>
                                </div>
                                <div className="d-flex justify-content-between approval-section py-2">
                                    <div className="d-flex flex-column">
                                        <div className="d-flex">
                                            <p className="font-weight-bold">HRMS</p>
                                        </div>
                                        <p>
                                            Leave Request
                                        </p>
                                    </div>
                                    <div className="d-flex align-items-center">
                                        <div className="text-left">
                                            <h2>2</h2>
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-between approval-section py-2">
                                    <div className="d-flex flex-column">
                                        <div className="d-flex">
                                            <p className="font-weight-bold">iExpense</p>
                                        </div>
                                        <p>
                                            Process
                                        </p>
                                    </div>
                                    <div className="d-flex align-items-center">
                                        <div className="text-left">
                                            <h2>4</h2>
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-between approval-section py-2">
                                    <div className="d-flex flex-column">
                                        <div className="d-flex">
                                            <p className="font-weight-bold">iExpense</p>
                                        </div>
                                        <p>
                                            Process
                                        </p>
                                    </div>
                                    <div className="d-flex align-items-center">
                                        <div className="text-left">
                                            <h2>1</h2>
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-between approval-section py-2">
                                    <div className="d-flex flex-column">
                                        <div className="d-flex">
                                            <p className="font-weight-bold">Whizible Initiative</p>
                                        </div>
                                        <p>
                                            Pending
                                        </p>
                                    </div>
                                    <div className="d-flex align-items-center">
                                        <div className="text-left">
                                            <h2>11</h2>
                                        </div>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <a href="#">View all</a>
                                </div>
                            </div>
                        </div>

                        <div className="col-lg-3 col-md-12 col-sm-12 mt-4">
                            <div className="card rounded p-3 my-documents fix-height">
                                <div className="title mb-2 d-flex align-items-center">
                                    <div className="d-flex rounded-circle circle-bg mr-2 justify-content-center align-items-center">
                                        <img src={iconDocument} alt="approval" />
                                    </div>
                                    <h6 className="mb-1 font-weight-bold">My Documents (8)</h6>
                                </div>
                                <div className="d-flex justify-content-start documents-section py-2">
                                    <div className="d-flex rect-bg mr-2 justify-content-center align-items-center">
                                        <img src={iconDocuments} alt="approval" />
                                    </div>
                                    <div className="d-flex flex-column">
                                        <div className="d-flex">
                                            <p className="document-title">Cheque collection policy</p>
                                        </div>
                                        <div className="small document-status">
                                            Last opened 3hr ago
                                        </div>
                                    </div>
                                    <div className="d-flex align-items-center ml-auto">
                                        <img src={iconShare} alt="share" />
                                    </div>
                                </div>
                                <div className="d-flex justify-content-start documents-section py-2">
                                    <div className="d-flex rect-bg mr-2 justify-content-center align-items-center">
                                        <img src={iconDocuments} alt="approval" />
                                    </div>
                                    <div className="d-flex flex-column">
                                        <div className="d-flex">
                                            <p className="document-title">List of outsourced vendors terminated by the Bank</p>
                                        </div>
                                        <div className="small document-status">
                                            Last opened 5hr ago
                                        </div>
                                    </div>
                                    <div className="d-flex align-items-center ml-auto">
                                        <img src={iconShare} alt="share" />
                                    </div>
                                </div>
                                <div className="d-flex justify-content-start documents-section py-2">
                                    <div className="d-flex rect-bg mr-2 justify-content-center align-items-center">
                                        <img src={iconDocument} alt="approval" />
                                    </div>
                                    <div className="d-flex flex-column">
                                        <div className="d-flex">
                                            <p className="document-title">Servicing you Safely</p>
                                        </div>
                                        <div className="small document-status">
                                            Last opened 5hr ago
                                        </div>
                                    </div>
                                    <div className="d-flex align-items-center ml-auto">
                                        <img src={iconShare} alt="share" />
                                    </div>
                                </div>
                                <div className="d-flex justify-content-start documents-section py-2">
                                    <div className="d-flex rect-bg mr-2 justify-content-center align-items-center">
                                        <img src={iconShare} alt="approval" />
                                    </div>
                                    <div className="d-flex flex-column">
                                        <div className="d-flex">
                                            <p className="document-title">Business Continuity Management</p>
                                        </div>
                                        <div className="small document-status">
                                            Last opened 1day ago
                                        </div>
                                    </div>
                                    <div className="d-flex align-items-center ml-auto">
                                        <img src={iconShare} alt="share" />
                                    </div>
                                </div>
                                <div className="text-right">
                                    <a href="#">View all</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <ProfileDetailsWidget description={this.props.description}></ProfileDetailsWidget>
                {/*Top Products widgets cards is started */}
                <div className="container text-left">
                    <div className="row">
                        <div className=" col-md-3 col-sm-12 mt-4 p-md-0 ">
                            <div className="card rounded p-3 topProducts fix-height">
                                <div className="title mb-2 d-flex align-items-center">
                                    <div className="d-flex rounded-circle circle-bg mr-2 justify-content-center align-items-center">
                                        <img src={iconDocument} alt="approval" />
                                    </div>
                                    <h6 className="mb-1 font-weight-bold">Top Products (7)</h6>
                                </div>
                                <div className="d-flex justify-content-start  py-2">
                                    <div className="d-flex productImg mr-2 justify-content-center align-items-center">
                                        <img src={ICICI_Mobile_app} alt="approval" />
                                    </div>
                                    <div className="d-flex flex-column">
                                        <div className="d-flex ml-2">
                                            <p className="productInfo">iMobile Pay App: One stop solution to all your banking and payment needs.</p>
                                        </div>
                                        <div className="small productStatus ml-2 mt-2">
                                            <span style={{ color: "#00ff00" }}>12,36,908 +</span> downloads in 24 hrs
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-start  py-2">
                                    <div className="d-flex productImg mr-2 justify-content-center align-items-center">
                                        <img src={Resolution_Covid} alt="approval" />
                                    </div>
                                    <div className="d-flex flex-column">
                                        <div className="d-flex ml-2">
                                            <p className="productInfo">Resolution Framework 2.0 for COVID-19 related stress – Guidelines</p>
                                        </div>
                                        <div className="small productStatus ml-2 mt-2">
                                            <span style={{ color: "#00ff00" }}>23,487 +</span> views in 8hrs
                                        </div>
                                    </div>
                                </div>

                                <div className="d-flex justify-content-start  py-2">
                                    <div className="d-flex productImg mr-2 justify-content-center align-items-center">
                                        <img src={ICICI_PhonePay} alt="approval" />
                                    </div>
                                    <div className="d-flex flex-column">
                                        <div className="d-flex ml-2">
                                            <p className="productInfo">ICICI Bank and PhonePe Partner to issue FASTag</p>
                                        </div>
                                        <div className="small productStatus ml-2 mt-2">
                                            <span style={{ color: "#00ff00" }}>43,56,989 +</span> views in 8hrs
                                        </div>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <a href="#">View all</a>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-4 col-sm-12 mt-4 pr-md-0">
                            <div className="card rounded p-3 fix-height">
                                <div className="title mb-2 d-flex align-items-center">
                                    <div className="d-flex rounded-circle circle-bg mr-2 justify-content-center align-items-center">
                                        <img src={iconApproval} alt="approval" />
                                    </div>
                                    <h6 className="mb-1 font-weight-bold">Product Presentation (4)</h6>
                                </div>
                                <div className="d-flex flex-column productInsideCard">
                                    <div className="d-flex ml-2">
                                        <p className="heading">Credit Cards</p>
                                    </div>
                                    <div className=" ml-2 mt-2">
                                        <p className="text">Credit Cards offer a host of benefits and offers to cater to your needs.</p>
                                    </div>
                                    <div className="subText ml-2 mt-2">
                                        13 products, 166 slides
                                    </div>
                                    <div className=" ml-2 mt-2">
                                        <a href="#" style={{ color: "#00ff00" }}>15 presentations</a>
                                    </div>
                                    <button type="button" className=" button btn btn-primary mr-0 mt-2" > Download all Credit Cards presentations</button>
                                </div>

                                <div className="d-flex flex-column productInsideCard">
                                    <div className="d-flex ml-2">
                                        <p className="heading">Loans</p>
                                    </div>
                                    <div className="ml-2 mt-2">
                                        <p className="text">Browse through a range of loans ICICI offers with affordable interest rates.</p>
                                    </div>
                                    <div className=" subText ml-2 mt-2">
                                        14 products, 189 slides
                                    </div>
                                    <div className=" ml-2 mt-2" >
                                        <a href="#" style={{ color: "#00ff00" }}>15 presentations</a>
                                    </div>
                                    <button type="button" className=" button btn btn-primary mr-0 mt-2" > Download all Loans presentations</button>
                                </div>
                            </div>
                        </div>

                        <div className="  col-md-5 col-sm-12 mt-4 ">
                            <div className="card rounded p-3  fix-height">
                                <div className="title mb-2 d-flex align-items-center">
                                    <div className="d-flex rounded-circle circle-bg mr-2 justify-content-center align-items-center">
                                        <img src={iconApproval} alt="approval" />
                                    </div>
                                    <h6 className="mb-1 font-weight-bold">Branch details and ATM availability</h6>
                                    <div className="d-flex rounded-circle circle-bg ml-auto justify-content-center align-items-center" >
                                        <img src={Group_8579} alt="settings" />
                                    </div>
                                </div>
                                <div className=" row pt-2 p-0">
                                    <div className="col-md-7 col-sm-12">
                                        <div className="inputSearch">
                                            <img src={searchIcon} alt="search " />
                                            <input type="email" className="form-control" placeholder="49/A Manmohan Banerje..." />
                                        </div>
                                    </div>
                                    <div className="col-md-5 col-sm-12 pl-0 dropDown dropDown-text">
                                        <select className="form-control">
                                            <option >Services</option>
                                            <option>option 1</option>
                                            <option>option 2</option>
                                            <option>option 3</option>
                                        </select>
                                    </div>
                                </div>

                                <div className="sub-header">
                                    <div className="sub-header-nav">
                                        <ul>
                                            <li><a href="#">Nearby Branches<span className="badge  notification1">16</span></a></li>
                                            <li><a href="#">ATMS<span className="badge  notification2">16</span></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div className="mt-4 ml-2">
                                    <p className="heading">ATMs in the area:</p>
                                </div>
                                <div className="productSubCard">
                                    <div className="row">
                                        <div className="col-md-3 col-sm-12 mapImg pl-2">
                                            <img src={map} alt="map" />
                                        </div>
                                        <div className="col-md-7">
                                            <div className="ml-2 ">
                                                <p className="heading">Buroshibtolla ATM</p>
                                            </div>
                                            <div className="small ml-2 mt-2">
                                                <span> 49/B Manmohan Banerjee Road,<br />Kolkata - 700038</span>
                                            </div>
                                            <div className="small ml-2 mt-2">
                                                <span >6am-9pm</span>
                                            </div>
                                        </div>
                                        <div className="col-md-2">
                                            <div className="status">
                                                <span style={{ color: "#00ff00" }}>open</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <a href="#">View details</a>
                                    </div>
                                </div>

                                <div className="productSubCard">
                                    <div className="row">
                                        <div className="col-md-3 col-sm-12 mapImg pl-2 ">
                                            <img src={map} alt="map" />
                                        </div>
                                        <div className="col-md-7">
                                            <div className="ml-2">
                                                <p className="heading">New Alipore ATM</p>
                                            </div>
                                            <div className="small ml-2 mt-2">
                                                <div>
                                                    <span >215 Alipore Road,</span><br />
                                                    <span>Kolkata - 700038</span></div>
                                            </div>
                                            <div className="small ml-2 mt-2">
                                                <span >Currently out of service</span>
                                            </div>
                                        </div>
                                        <div className="col-md-2 pl-2">
                                            <div className="status">
                                                <span>closed</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <a href="#">View details</a>
                                    </div>
                                </div>

                                <div className="productSubCard">
                                    <div className="row">
                                        <div className="col-md-3 col-sm-12 mapImg pl-2 ">
                                            <img src={map} alt="map" />
                                        </div>
                                        <div className="col-md-7">
                                            <div className="ml-2">
                                                <p className="heading">New Road ATM</p>
                                            </div>
                                            <div className="small ml-2 mt-2">
                                                <span>13/D New Road,</span><br />
                                                <span>Kolkata - 700038</span>
                                            </div>
                                            <div className="small ml-2 mt-2">
                                                <span >6am-11pm</span>
                                            </div>
                                        </div>
                                        <div className="col-md-2">
                                            <div className="status">
                                                <span style={{ color: "#00ff00" }}>open</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="text-right">
                                        <a href="#">View details</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
                {/* Top Prodects Widgets cards is ended */}
                {/* Bank achievements and Competitive interest rates & fees cards stared */}
                <div className=" container ">
                    <div className="row">

                        <div className="col-lg-6 col-md-12 col-sm-12 mb-4 p-md-0  mt-4">
                            <div className="card rounded p-3 my-approvals custom-height" style={{ height: "665px", overflowY: "scroll" }}>
                                <div className="title mb-2 d-flex align-items-center">
                                    <h6 className="mb-1 font-weight-bold">Notable Bank Achievements</h6>
                                </div>
                                <div className="survey-section position-relative text-white rounded">
                                    <h3 className="mb-2">ICICI Bank and<br />PhonePe Partner to</h3>
                                    <p className="rm-custom">PhonePe users would now get a fully digitised experience; wouldn’t have to visit physical stores, toll locations to buy a</p>
                                    <img src={iconAnnouncement} className="right-section position-absolute" alt="share" />
                                </div>
                                <div className="card d-flex flex-row shadow-none p-2 mt-3">
                                    <div className="pr-2">
                                        <img src={iconAnnouncement} alt="share" />
                                    </div>
                                    <div className="d-flex flex-column">
                                        <div className="d-flex pb-2">
                                            <p className="font-weight-bold">ICICI Bank</p>
                                        </div>
                                        <p>
                                            ICICI Bank welcomes you! Follow us for global news, offers, banking on twitter, campaigns &amp; financial education. For service queries, tag @ICICIBank_Care
                                        </p>
                                    </div>
                                </div>
                                <div className="card d-flex flex-row shadow-none p-2 mt-3">
                                    <div className="pr-2">
                                        <img src={iconAnnouncement} alt="share" />
                                    </div>
                                    <div className="d-flex flex-column">
                                        <p className="border-bottom pb-2 mb-2">ICICI Bank launches instant EMI facility on internet; makes high value items affordable to customers</p>
                                        <p>ICICI Foundation and department of college education, government of Rajasthan sign MoU.</p>
                                    </div>
                                </div>
                                <div className="card shadow-none mt-3">
                                    <img src={sample_card} className="card-img-top" alt="..." />
                                    <div className="card-body p-2">
                                        <p className="card-text">ICICI Bank to bear cost of COVID-19 vaccination for employees, families</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-lg-6 col-md-12 col-sm-12 mb-4 mt-4">
                            <div className="card rounded p-3">
                                <div className="title mb-2 d-flex align-items-center position-relative">
                                    <div className="d-flex rounded-circle circle-bg mr-2 justify-content-center align-items-center">
                                        <img src={iconApproval} alt="approval" />
                                    </div>
                                    <h6 className="mb-1 font-weight-bold">Frequently viewed interest rates</h6>
                                    <img src={iconApproval} alt="approval" className="title-right-icon position-absolute" />
                                </div>
                                <div className="card d-flex flex-sm-row flex-wrap justify-content-between shadow-none border-0 mt-3">
                                    <div className="sqr-box d-flex flex-column p-2 text-white rounded">
                                        <h6 className="text-uppercase font-weight-bold">Saving Accounts</h6>
                                        <div className="bottom">
                                            <span>From</span>
                                            <h6>3%-3.7%</h6>
                                        </div>
                                    </div>
                                    <div className="sqr-box d-flex flex-column p-2 text-white rounded">
                                        <h6 className="text-uppercase font-weight-bold">FIXED DEPOSIT</h6>
                                        <div className="bottom">
                                            <span>From</span>
                                            <h6>5.5%-6%</h6>
                                        </div>
                                    </div>
                                    <div className="sqr-box d-flex flex-column p-2 text-white rounded">
                                        <h6 className="text-uppercase font-weight-bold">PERSONAL LOAN</h6>
                                        <div className="bottom">
                                            <span>From</span>
                                            <h6>10.50%-11%</h6>
                                        </div>
                                    </div>
                                    <div className="sqr-box d-flex flex-column p-2 text-white rounded">
                                        <h6 className="text-uppercase font-weight-bold">HOME LOAN</h6>
                                        <div className="bottom">
                                            <span>From</span>
                                            <h6>6.75%-7%</h6>
                                        </div>
                                    </div>
                                    <div className="sqr-box d-flex flex-column p-2 text-white rounded">
                                        <h6 className="text-uppercase font-weight-bold">REPO RATE</h6>
                                        <div className="bottom">
                                            <span>From</span>
                                            <h6>4%-4.75%</h6>
                                        </div>
                                    </div>
                                    <div className="sqr-box d-flex flex-column p-2 text-white rounded">
                                        <h6 className="text-uppercase font-weight-bold">GOLD LOAN</h6>
                                        <div className="bottom">
                                            <span>From</span>
                                            <h6>0.99%-1.50%</h6>
                                        </div>
                                    </div>
                                </div>
                                <div className="text-right">
                                    <a href="#"><u>View all</u></a>
                                </div>
                            </div>

                            <div className="card rounded p-3 mt-3">
                                <div className="text-left mb-2">
                                    <a href="#"><u>Go back</u></a>
                                </div>
                                <div className="title d-flex align-items-center position-relative">
                                    <h6 className="mb-0 font-weight-bold">Select interest rates you’d like to see:</h6>
                                </div>
                                <div className="text-left mb-3">
                                    <span className="small">(6 out of 6  )</span>
                                </div>
                                <div className="d-flex flex-wrap checkbox-section">
                                    <div className="custom-control custom-checkbox mb-2">
                                        <input type="checkbox" className="custom-control-input" id="customCheck1" />
                                        <label className="custom-control-label" htmlFor="customCheck1">Home Loan</label>
                                    </div>
                                    <div className="custom-control custom-checkbox mb-2">
                                        <input type="checkbox" className="custom-control-input" id="customCheck2" />
                                        <label className="custom-control-label" htmlFor="customCheck2">Saving Account</label>
                                    </div>
                                    <div className="custom-control custom-checkbox mb-2">
                                        <input type="checkbox" className="custom-control-input" id="customCheck3" />
                                        <label className="custom-control-label" htmlFor="customCheck3">Car Loan</label>
                                    </div>
                                    <div className="custom-control custom-checkbox mb-2">
                                        <input type="checkbox" className="custom-control-input" id="customCheck4" />
                                        <label className="custom-control-label" htmlFor="customCheck4">Salary Account</label>
                                    </div>
                                    <div className="custom-control custom-checkbox mb-2">
                                        <input type="checkbox" className="custom-control-input" id="customCheck5" />
                                        <label className="custom-control-label" htmlFor="customCheck5">Gold Loan</label>
                                    </div>
                                    <div className="custom-control custom-checkbox mb-2">
                                        <input type="checkbox" className="custom-control-input" id="customCheck6" />
                                        <label className="custom-control-label" htmlFor="customCheck6">Business Account</label>
                                    </div>
                                </div>
                                <div className="text-center">
                                    <button type="button" className="btn btn-primary px-4 text-white mt-3">Save changes</button>
                                </div>
                            </div>
                        </div>
                        {/* Bank achievements and Competitive interest rates & fees cards ended  */}

                    </div>
                    <div className="row">
                        {/* Summary of numbers like revenue & projections and Bank’s initiatives*/}
                        <div className="col-md-6 col-sm-12 mb-2 p-md-0">
                            <div className="card d-flex shadow-none p-2 mt-3" style={{ height: "315px", overflowY: "scroll" }}>
                                <div className="title mb-2 d-flex align-items-center">
                                    <div className="d-flex rounded-circle circle-bg mr-2 justify-content-center align-items-center">
                                        <img src={iconApproval} alt="approval" />
                                    </div>
                                    <h6 className="mb-1 font-weight-bold">Bank Initiatives (28)</h6>
                                    <div className="select-section ml-auto">
                                        <select name="years" className="custom-select">
                                            <option  >2021</option>
                                            <option value="2020">2020</option>
                                            <option value="2019">2019</option>
                                            <option value="2018">2018</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="d-flex border-bottom pb-3 mb-3">
                                    <div className="mr-3 img-box d-flex">
                                        <img src={img_square} alt="card" className="rounded" />
                                    </div>
                                    <div className="d-flex flex-column">
                                        <div className="text-left mb-1">
                                            <span className="small">July 06</span>
                                        </div>
                                        <p className="small mb-1">Amazon Pay ICICI Bank credit card on-boards over two million…</p>
                                        <div className="pr-2">
                                            <a href="#" className="mr-2"><img src={iconShare} alt="download" />Download</a>
                                            <a href="#"><img src={iconShare} alt="share" />Share</a>
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex border-bottom pb-3 mb-3">
                                    <div className="mr-3 img-box d-flex">
                                        <img src={img_square} alt="card" className="rounded" />
                                    </div>
                                    <div className="d-flex flex-column">
                                        <div className="text-left mb-1">
                                            <span className="small">June 21</span>
                                        </div>
                                        <p className="small mb-1">ICICI Bank extends instant ‘Cardless EMI’ for online shopping; enhances…</p>
                                        <div className="pr-2">
                                            <a href="#" className="mr-2"><img src={iconShare} alt="download" />Download</a>
                                            <a href="#"><img src={iconShare} alt="share" />Share</a>
                                        </div>
                                    </div>
                                </div>
                                <div className="d-flex mb-3">
                                    <div className="mr-3 img-box d-flex">
                                        <img src={img_square} alt="card" className="rounded" />
                                    </div>
                                    <div className="d-flex flex-column">
                                        <div className="text-left mb-1">
                                            <span className="small">June 16</span>
                                        </div>
                                        <p className="small mb-1">ICICI Bank extends instant ‘Cardless EMI’ for online shopping; enhances…</p>
                                        <div className="pr-2">
                                            <a href="#" className="mr-2"><img src={iconShare} alt="download" />Download</a>
                                            <a href="#"><img src={iconShare} alt="share" />Share</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="col-md-6 col-sm-12 mb-2">
                            <div className="card d-flex shadow-none p-3 mt-3 financial-section">
                                <div className="title mb-2 d-flex align-items-center">
                                    <div className="d-flex rounded-circle circle-bg mr-2 justify-content-center align-items-center">
                                        <img src={iconDocuments} alt="approval" />
                                    </div>
                                    <h6 className="mb-1 font-weight-bold">Financial Highlights</h6>
                                    <div className="select-section ml-auto">
                                        <select name="years" className="custom-select">
                                            <option  >Fiscal 2019 - 2020</option>
                                            <option value="2020">2020</option>
                                            <option value="2019">2019</option>
                                            <option value="2018">2018</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="card d-flex flex-sm-row shadow-none px-3 py-2 mb-2 bg-color">
                                    <div className="d-flex flex-column w-50 border-right">
                                        <div className="text-left mb-1">
                                            <span className="small">Net interest income and other income</span>
                                        </div>
                                        <h3 className="m-0 font-weight-bold text-primary">&#8377; 497.16 Bn</h3>
                                    </div>
                                    <div className="d-flex flex-column w-50 text-right">
                                        <div className="mb-1">
                                            <span className="small">vs Fiscal 2019</span>
                                        </div>
                                        <h3 className="m-0 font-weight-bold text-success">&#8593; 19.7%</h3>
                                    </div>
                                </div>
                                <div className="d-flex flex-wrap justify-content-between financial-list px-1">
                                    <div className="d-flex mb-2 border-bottom pb-2 inner-box">
                                        <div className="d-flex flex-column">
                                            <div className="text-left mb-1">
                                                <span className="small">Operating Expenses</span>
                                            </div>
                                            <h4 className="m-0">&#8377; 216.14 Bn</h4>
                                        </div>
                                        <div className="text-left ml-auto mt-auto">
                                            <span className="small font-weight-bold green-fin">&#8593; 19.5%</span>
                                        </div>
                                    </div>
                                    <div className="d-flex mb-2 border-bottom pb-2 inner-box">
                                        <div className="d-flex flex-column">
                                            <div className="text-left mb-1">
                                                <span className="small">Operating Profit</span>
                                            </div>
                                            <h4 className="m-0">&#8377; 281.01 Bn</h4>
                                        </div>
                                        <div className="text-left ml-auto mt-auto">
                                            <span className="small font-weight-bold green-fin">&#8593; 19.9%</span>
                                        </div>
                                    </div>
                                    <div className="d-flex mb-2 border-bottom pb-2 inner-box">
                                        <div className="d-flex flex-column">
                                            <div className="text-left mb-1">
                                                <span className="small">Core Operating Profit</span>
                                            </div>
                                            <h4 className="m-0">&#8377; 268.08 Bn</h4>
                                        </div>
                                        <div className="text-left ml-auto mt-auto">
                                            <span className="small font-weight-bold green-fin">&#8593; 21.5%</span>
                                        </div>
                                    </div>
                                    <div className="d-flex mb-2 border-bottom pb-2 inner-box">
                                        <div className="d-flex flex-column">
                                            <div className="text-left mb-1">
                                                <span className="small">Provisions & Contingencies</span>
                                            </div>
                                            <h4 className="m-0">&#8377; 140.53 Bn</h4>
                                        </div>
                                        <div className="text-left ml-auto mt-auto">
                                            <span className="small font-weight-bold red-fin">&#8595; 28.5%</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {/* Credit/loan options block is started */}
                <div className=" container CreditLoanCard mt-3">
                    <div className="row">
                        <div className="col-lg-4 col-md-6 p-md-0 ">
                            <div className="card team-chart1  mt-2" style={{ height: "500px" }}>
             
                                <div className="row mt-2 sub-head">
                                    <div className="col-lg-6 col-md-6 col-sm-12">
                                        <form>
                                            <div className="form-group formData">
                                                <label>Prodect Category</label>
                                                <select className="form-control dropDown-text">
                                                    <option>Select Category</option>
                                                    <option>Option 1</option>
                                                    <option>Option 2</option>
                                                    <option>Option 3</option>
                                                    <option>Option 4</option>
                                                    <option>Option 5</option>
                                                </select>
                                            </div>
                                        </form>
                                    </div>
                                    <div className="col-lg-6 col-md-6 col-sm-12">
                                        <form>
                                            <div className="form-group formData">
                                                <label>Sort By</label>
                                                <select className="form-control dropDown-text">
                                                    <option>Latest</option>
                                                    <option>Option 1</option>
                                                    <option>Option 2</option>
                                                    <option>Option 3</option>
                                                    <option>Option 4</option>
                                                    <option>Option 5</option>
                                                </select>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div className=" mt-2 ml-3">
                                    <h5 className="creditHeading">Latest products from all categories</h5>
                                </div>
                                <div className=" mt-2 ml-3">
                                    <p>Credit Cards</p>
                                </div>
                                <div className="creadit-loan-cards scroll-custom card-data">
                                    <div className="container">
                                        <div id="accordion">
                                            <div className="card mb-2 mt-2">
                                                <div className="card-header-details" id="headingOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                    <div className="creadit-products1">
                                                        <img src={Group_9} alt="creadit-card-img" />
                                                    </div>
                                                    <div className=" row ">
                                                        
                                                            <div className="creditHeading float-left col-lg-7">Emeralde</div>
                                                            <div className=" creditNotification1 col-lg-2 p-0">New</div>

                                                      
                                                        <div className="col-lg-3">
                                                            <Link className="float-right mt-3" to={"/NewPage"} ><FontAwesomeIcon icon={faChevronRight} /></Link>
                                                        </div>
                                                        <div className="cardText col-lg-12 pt-0">Net Annual Income: INR 5 lakhs</div>


                                                    </div>
                                                </div>

                                            </div>

                                            <div className="card mb-2 mt-2">
                                                <div className="card-header-details" id="headingOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                    <div className="creadit-products1">
                                                        <img src={Group_9} alt="creadit-card-img" />
                                                    </div>
                                                    <div className=" row ">
                                                       
                                                            <div className="creditHeading float-left col-lg-7">Coral</div>
                                                            <div className=" creditNotification1 p-0 col-lg-2">New</div> 

                                              
                                                        <div className="col-lg-3">
                                                            <Link className="float-right mt-3" to={"/NewPage"} ><FontAwesomeIcon icon={faChevronRight} /></Link>
                                                        </div>
                                                        <div className="cardText col-lg-12 pt-0">Net Annual Income: INR 10 lakhs</div>


                                                    </div>
                                                </div>

                                            </div>

                                        </div>
                                        <div className=" mt-2 ml-2">
                                            <p>Loans</p>
                                        </div>
                                        <div className="card mb-2 mt-2">
                                            <div className="card-header-details" id="headingOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                <div className="creadit-products1">
                                                    <img src={Group_9} alt="creadit-card-img" />
                                                </div>
                                                <div className=" row ">
                                                   
                                                        <div className="creditHeading float-left  col-lg-7">Mortgage loan</div>
                                                        <div className="creditNotification col-lg-2 p-0 mt-3">New</div>

                                                    
                                                    <div className="col-lg-3">
                                                        <Link className="float-right mt-3" to={"/NewPage2"} ><FontAwesomeIcon icon={faChevronRight} /></Link>
                                                    </div>
                                                    <div className="cardText col-lg-12 pt-0">Net Annual Income: INR 5 lakhs</div>

                                                </div>
                                            </div>

                                        </div> 
                                        <div className="card mb-2 mt-2">
                                            <div className="card-header-details" id="headingOne" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                <div className="creadit-products1">
                                                    <img src={Group_9} alt="creadit-card-img" />
                                                </div>
                                                <div className=" row ">
                                                    
                                                        <div className="creditHeading float-left col-lg-7">Education loan</div>
                                                        <div className=" creditNotification col-lg-2 p-0 mt-3 ">New</div>

                                                    
                                                    <div className="col-lg-3">
                                                        <Link className="float-right mt-3" to={"/NewPage2"} ><FontAwesomeIcon icon={faChevronRight} /></Link>
                                                    </div>

                                                    <div className="cardText col-lg-12 pt-0">Net Annual Income: INR 10 lakhs</div>

                                                </div>
                                            </div>

                                        </div>


                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
                {/* Credit/loan options block is ended */}
                {/* Summary of numbers like revenue & projections and Bank’s initiatives */}
                <div className='container'>
                    <div className="row">
                        <div className="col-lg-6 col-md-12 col-sm-12 p-md-0 mt-4 ">
                            <div className="card line-chart-card  mt-2 " >
                                <div className="header-section mb-3">
                                    <img src={Path_5597} />
                                    <span className="header-title">Total Loans & Deposits</span>
                                    {/* <span style={{ display: "block" }}>12 Month Trend (In Bn)</span> */}
                                    <img className=" float-right" src={Group_8579} />
                                </div>

                                <div className="card-body teams-chart-body1 mb-2" style={{ padding: "0px" }}>
                                    <div className="row mt-2">
                                        <div className="col-lg-4 col-md-4 col-sm-12">
                                            <form>
                                                <div className="form-group formData">
                                                    <label>REGIONS:</label>
                                                    <select className="form-control custom-select">
                                                        <option>Karnataka</option>
                                                        <option>Andra Pradhesh</option>
                                                        <option>Kerala</option>
                                                        <option>Maharastra</option>
                                                        <option>Gujarat</option>
                                                        <option>Madhya Pradesh</option>
                                                    </select>
                                                </div>
                                            </form>
                                        </div>
                                        <div className="col-lg-4 col-md-4 col-sm-12">
                                            <form>
                                                <div className="form-group formData">
                                                    <label>City</label>
                                                    <select className="form-control custom-select">
                                                        <option>Bangalore</option>
                                                        <option>Mysure</option>
                                                        <option>Option 3</option>
                                                        <option>Option 4</option>
                                                        <option>Option 5</option>
                                                    </select>
                                                </div>
                                            </form>
                                        </div>
                                        <div className="col-lg-4 col-md-4 col-sm-12">
                                            <form>
                                                <div className="form-group formData">
                                                    <label>DATE RANGE</label>
                                                    <DateRangePicker><input type="input" className="form-control" /></DateRangePicker>
                                                </div>
                                            </form>
                                        </div>
                                        <div className="file-downolading-data col-lg-12 col-md-12 col-sm-12 mt-3">
                                            <a href="">Download Report</a>
                                            <img className="file-downolading" src={downloadingIcon} />
                                        </div>
                                        <div className="col-lg-12 col-md-12 col-sm-12 mt-4 pt-4">
                                            <ReactEcharts
                                                option={{
                                                    legend: {},
                                                    tooltip: {
                                                        trigger: 'axis',
                                                        showContent: true
                                                    },
                                                    dataset: {
                                                        source: [
                                                            ['product', 'jan 2012', 'feb 2012', 'Mar 2012', 'Apr 2012', 'May 2012', 'June 2012', 'July 2012', 'Aug 2012', 'Sep 2012', 'Oct 2012', 'Nov 2012', 'Dec 2012'],
                                                            ['Deposit', 56.5, 82.1, 88.7, 70.1, 53.4, 85.1, 87.5, 61.2, 95.2, 50.7, 98.6, 101.3],
                                                            ['Loans', 51.1, 51.4, 55.1, 53.3, 73.8, 68.7, 70.5, 74.6, 79.6, 81.9, 83.4, 89.8],
                                                        ]
                                                    },
                                                    xAxis: {
                                                        type: 'category',
                                                        nameGap: 40,
                                                        boundaryGap: true,
                                                        splitNumber: 12,
                                                        nameLocation: 'middle',
                                                        name: 'Time in Months',
                                                        splitLine: {
                                                            show: false
                                                        },
                                                    },
                                                    yAxis: {
                                                        gridIndex: 0,
                                                        nameGap: 40,
                                                        nameLocation: 'middle',
                                                        name: '₹ in Billion',
                                                        splitLine: {
                                                            show: false
                                                        },
                                                    },
                                                    series: [
                                                        { type: 'line', smooth: true, seriesLayoutBy: 'row', emphasis: { focus: 'series' } },
                                                        { type: 'line', smooth: true, seriesLayoutBy: 'row', emphasis: { focus: 'series' } },
                                                    ]
                                                }}
                                            />
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div className="col-lg-6 col-md-12 col-sm-12 mt-4 ">
                            <div className="card line-chart-card mt-2 ">
                                <GroupBarChart></GroupBarChart>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="row">
                    <div className=" col-lg-12 line-chart-card  mt-2 ">
                        <GroupChart></GroupChart>
                    </div>
                </div>

                <div>
                    {/* Home page social-media cards is started */}
                    <div className="container">
                        <div className="row">
                            {/* Home page Teams chart card started */}
                            <div className=" p-md-0 mt-4">
                                <div className="card team-chart ">
                                    <div className="header-section mb-3">
                                        <img src={Path_5597} />
                                        <span className="header-title">Social Media</span>
                                        <img className=" float-right" src={Group_8579} />
                                    </div>

                                    <ul className="nav nav-tabs" id="myTab" role="tablist">
                                        <li className="nav-item" role="presentation">
                                            <a className="nav-link " id="twitter-tab" data-toggle="tab" href="#twitter" role="tab" aria-controls="twitter" aria-selected="true">Twitter</a>
                                        </li>
                                        <li className="nav-item" role="presentation">
                                            <a className="nav-link" id="facebook-tab" data-toggle="tab" href="#facebook" role="tab" aria-controls="facebook" aria-selected="false">Facebook</a>
                                        </li>
                                        <li className="nav-item" role="presentation">
                                            <a className="nav-link" id="linkedIn-tab" data-toggle="tab" href="#linkedIn" role="tab" aria-controls="linkedIn" aria-selected="false">LinkedIn</a>
                                        </li>
                                        <li className="nav-item" role="presentation">
                                            <a className="nav-link" id="instagram-tab" data-toggle="tab" href="#instagram" role="tab" aria-controls="instagram" aria-selected="false">Instagram</a>
                                        </li>
                                    </ul>

                                    <div className="scroll-custom card-data">
                                        <div className="card-body teams-chart-body mb-2" style={{ padding: "0px" }}>
                                            <div className="card d-flex shadow-none p-2 mt-3">
                                                <div className="tab-content" id="myTabContent">
                                                    <div className="tab-pane fade show active" id="twitter" role="tabpanel" aria-labelledby="twitter-tab">
                                                        <Timeline
                                                            dataSource={{
                                                                sourceType: 'profile',
                                                                screenName: 'icicibank'
                                                            }}
                                                            options={{
                                                                height: '470',
                                                                width: '340'
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="tab-pane fade" id="facebook" role="tabpanel" aria-labelledby="facebook-tab">
                                                        {/* <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ficicibank%2F&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=919180515344689" width="340" height="470" style={{border:"none", overflow:"hidden"}} scrolling="no" frameBorder="0" allowFullScreen={true} allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe> */}

                                                        {/* <Iframe className="iframe-fb" url="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Ficicibank&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId"  width="340" height="500"  scrolling="yes" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></Iframe> */}

                                                        <div className="fb-page" data-tabs="timeline,events,messages" data-href="https://www.facebook.com/icicibank" data-width="340" data-height="500" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-lazy="true" data-show-facepile="true"></div>

                                                    </div>
                                                    <div className="tab-pane fade" id="linkedIn" role="tabpanel" aria-labelledby="linkedIn-tab"><iframe src="https://www.linkedin.com/embed/feed/update/urn:li:share:6840567153498845184" height="494" width="340" frameBorder="0" title="Embedded post"></iframe></div>
                                                    <div className="tab-pane fade" id="instagram" role="tabpanel" aria-labelledby="instagram-tab"></div >
                                                </div >

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* Home page social-media cards is ended */}

                </div>
                {/* <blockquote className="instagram-media" data-instgrm-captioned data-instgrm-permalink="https://www.instagram.com/p/CTmvDicCy4c/?utm_source=ig_embed&amp;utm_campaign=loading" data-instgrm-version="13" ><div > <a href="https://www.instagram.com/p/CTmvDicCy4c/?utm_source=ig_embed&amp;utm_campaign=loading"  target="_blank"> <div> <div></div> <div > <div></div> <div></div></div></div><div ></div> <div ><svg width="50px" height="50px" viewBox="0 0 60 60" version="1.1" xmlns="https://www.w3.org/2000/svg" 
                    xmlnsXlink="https://www.w3.org/1999/xlink"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><g transform="translate(-511.000000, -20.000000)" fill="#000000"><g><path d="M556.869,30.41 C554.814,30.41 553.148,32.076 553.148,34.131 C553.148,36.186 554.814,37.852 556.869,37.852 C558.924,37.852 560.59,36.186 560.59,34.131 C560.59,32.076 558.924,30.41 556.869,30.41 M541,60.657 C535.114,60.657 530.342,55.887 530.342,50 C530.342,44.114 535.114,39.342 541,39.342 C546.887,39.342 551.658,44.114 551.658,50 C551.658,55.887 546.887,60.657 541,60.657 M541,33.886 C532.1,33.886 524.886,41.1 524.886,50 C524.886,58.899 532.1,66.113 541,66.113 C549.9,66.113 557.115,58.899 557.115,50 C557.115,41.1 549.9,33.886 541,33.886 M565.378,62.101 C565.244,65.022 564.756,66.606 564.346,67.663 C563.803,69.06 563.154,70.057 562.106,71.106 C561.058,72.155 560.06,72.803 558.662,73.347 C557.607,73.757 556.021,74.244 553.102,74.378 C549.944,74.521 548.997,74.552 541,74.552 C533.003,74.552 532.056,74.521 528.898,74.378 C525.979,74.244 524.393,73.757 523.338,73.347 C521.94,72.803 520.942,72.155 519.894,71.106 C518.846,70.057 518.197,69.06 517.654,67.663 C517.244,66.606 516.755,65.022 516.623,62.101 C516.479,58.943 516.448,57.996 516.448,50 C516.448,42.003 516.479,41.056 516.623,37.899 C516.755,34.978 517.244,33.391 517.654,32.338 C518.197,30.938 518.846,29.942 519.894,28.894 C520.942,27.846 521.94,27.196 523.338,26.654 C524.393,26.244 525.979,25.756 528.898,25.623 C532.057,25.479 533.004,25.448 541,25.448 C548.997,25.448 549.943,25.479 553.102,25.623 C556.021,25.756 557.607,26.244 558.662,26.654 C560.06,27.196 561.058,27.846 562.106,28.894 C563.154,29.942 563.803,30.938 564.346,32.338 C564.756,33.391 565.244,34.978 565.378,37.899 C565.522,41.056 565.552,42.003 565.552,50 C565.552,57.996 565.522,58.943 565.378,62.101 M570.82,37.631 C570.674,34.438 570.167,32.258 569.425,30.349 C568.659,28.377 567.633,26.702 565.965,25.035 C564.297,23.368 562.623,22.342 560.652,21.575 C558.743,20.834 556.562,20.326 553.369,20.18 C550.169,20.033 549.148,20 541,20 C532.853,20 531.831,20.033 528.631,20.18 C525.438,20.326 523.257,20.834 521.349,21.575 C519.376,22.342 517.703,23.368 516.035,25.035 C514.368,26.702 513.342,28.377 512.574,30.349 C511.834,32.258 511.326,34.438 511.181,37.631 C511.035,40.831 511,41.851 511,50 C511,58.147 511.035,59.17 511.181,62.369 C511.326,65.562 511.834,67.743 512.574,69.651 C513.342,71.625 514.368,73.296 516.035,74.965 C517.703,76.634 519.376,77.658 521.349,78.425 C523.257,79.167 525.438,79.673 528.631,79.82 C531.831,79.965 532.853,80.001 541,80.001 C549.148,80.001 550.169,79.965 553.369,79.82 C556.562,79.673 558.743,79.167 560.652,78.425 C562.623,77.658 564.297,76.634 565.965,74.965 C567.633,73.296 568.659,71.625 569.425,69.651 C570.167,67.743 570.674,65.562 570.82,62.369 C570.966,59.17 571,58.147 571,50 C571,41.851 570.966,40.831 570.82,37.631"></path></g></g></g></svg></div><div > <div > View this post on Instagram</div></div><div></div> <div ><div> <div ></div> <div></div> <div ></div></div><div> <div ></div> <div></div></div><div > <div ></div> <div ></div> <div></div></div></div> <div > <div ></div> <div></div></div></a><p ><a href="https://www.instagram.com/p/CTmvDicCy4c/?utm_source=ig_embed&amp;utm_campaign=loading"  target="_blank">A post shared by ICICI Bank (@icicibank)</a></p></div></blockquote> <script async src="//www.instagram.com/embed.js"></script> */}
                {/* <blockquote className="instagram-media" data-instgrm-captioned data-instgrm-permalink="https://www.instagram.com/p/CTrjlFiNxNh/?utm_source=ig_embed&amp;utm_campaign=loading" data-instgrm-version="13" ><div > <a href="https://www.instagram.com/p/CTrjlFiNxNh/?utm_source=ig_embed&amp;utm_campaign=loading"  target="_blank"> <div > <div ></div> <div > <div ></div> <div ></div></div></div><div ></div> <div ><svg width="50px" height="50px" viewBox="0 0 60 60" version="1.1" xmlns="https://www.w3.org/2000/svg" xmlnsXlink="https://www.w3.org/1999/xlink"><g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd"><g transform="translate(-511.000000, -20.000000)" fill="#000000"><g><path d="M556.869,30.41 C554.814,30.41 553.148,32.076 553.148,34.131 C553.148,36.186 554.814,37.852 556.869,37.852 C558.924,37.852 560.59,36.186 560.59,34.131 C560.59,32.076 558.924,30.41 556.869,30.41 M541,60.657 C535.114,60.657 530.342,55.887 530.342,50 C530.342,44.114 535.114,39.342 541,39.342 C546.887,39.342 551.658,44.114 551.658,50 C551.658,55.887 546.887,60.657 541,60.657 M541,33.886 C532.1,33.886 524.886,41.1 524.886,50 C524.886,58.899 532.1,66.113 541,66.113 C549.9,66.113 557.115,58.899 557.115,50 C557.115,41.1 549.9,33.886 541,33.886 M565.378,62.101 C565.244,65.022 564.756,66.606 564.346,67.663 C563.803,69.06 563.154,70.057 562.106,71.106 C561.058,72.155 560.06,72.803 558.662,73.347 C557.607,73.757 556.021,74.244 553.102,74.378 C549.944,74.521 548.997,74.552 541,74.552 C533.003,74.552 532.056,74.521 528.898,74.378 C525.979,74.244 524.393,73.757 523.338,73.347 C521.94,72.803 520.942,72.155 519.894,71.106 C518.846,70.057 518.197,69.06 517.654,67.663 C517.244,66.606 516.755,65.022 516.623,62.101 C516.479,58.943 516.448,57.996 516.448,50 C516.448,42.003 516.479,41.056 516.623,37.899 C516.755,34.978 517.244,33.391 517.654,32.338 C518.197,30.938 518.846,29.942 519.894,28.894 C520.942,27.846 521.94,27.196 523.338,26.654 C524.393,26.244 525.979,25.756 528.898,25.623 C532.057,25.479 533.004,25.448 541,25.448 C548.997,25.448 549.943,25.479 553.102,25.623 C556.021,25.756 557.607,26.244 558.662,26.654 C560.06,27.196 561.058,27.846 562.106,28.894 C563.154,29.942 563.803,30.938 564.346,32.338 C564.756,33.391 565.244,34.978 565.378,37.899 C565.522,41.056 565.552,42.003 565.552,50 C565.552,57.996 565.522,58.943 565.378,62.101 M570.82,37.631 C570.674,34.438 570.167,32.258 569.425,30.349 C568.659,28.377 567.633,26.702 565.965,25.035 C564.297,23.368 562.623,22.342 560.652,21.575 C558.743,20.834 556.562,20.326 553.369,20.18 C550.169,20.033 549.148,20 541,20 C532.853,20 531.831,20.033 528.631,20.18 C525.438,20.326 523.257,20.834 521.349,21.575 C519.376,22.342 517.703,23.368 516.035,25.035 C514.368,26.702 513.342,28.377 512.574,30.349 C511.834,32.258 511.326,34.438 511.181,37.631 C511.035,40.831 511,41.851 511,50 C511,58.147 511.035,59.17 511.181,62.369 C511.326,65.562 511.834,67.743 512.574,69.651 C513.342,71.625 514.368,73.296 516.035,74.965 C517.703,76.634 519.376,77.658 521.349,78.425 C523.257,79.167 525.438,79.673 528.631,79.82 C531.831,79.965 532.853,80.001 541,80.001 C549.148,80.001 550.169,79.965 553.369,79.82 C556.562,79.673 558.743,79.167 560.652,78.425 C562.623,77.658 564.297,76.634 565.965,74.965 C567.633,73.296 568.659,71.625 569.425,69.651 C570.167,67.743 570.674,65.562 570.82,62.369 C570.966,59.17 571,58.147 571,50 C571,41.851 570.966,40.831 570.82,37.631"></path></g></g></g></svg></div><div > <div> View this post on Instagram</div></div><div ></div> <div ><div> <div ></div> <div ></div> <div ></div></div><div > <div ></div> <div></div></div><div > <div ></div> <div ></div> <div ></div></div></div> <div > <div ></div> <div ></div></div></a><p ><a href="https://www.instagram.com/p/CTrjlFiNxNh/?utm_source=ig_embed&amp;utm_campaign=loading" target="_blank">A post shared by Wipro (@wiprolimited)</a></p></div></blockquote> <script async src="//www.instagram.com/embed.js"></script> */}
            </div>

        );

    }
}