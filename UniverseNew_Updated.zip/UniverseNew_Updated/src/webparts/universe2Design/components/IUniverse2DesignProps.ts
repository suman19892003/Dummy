export interface IUniverse2DesignProps {
  description: string;
}
