import * as React from 'react';
import { Bar, Line } from "react-chartjs-2";
import "./styles/style.css";
import DateRangePicker from 'react-bootstrap-daterangepicker';
const iconApproval: any = require('./images/icon-approval.svg');

export default class GroupChart extends React.Component {

    public barData = {
        labels: [2017, 2018, 2019, 2020],
        datasets: [
            {
                label: 'Expenditure',
                data: [1020.57, 1098.7, 1256.17, 1385.61],
                backgroundColor: '#E07F31',
            }
        ]
    };

    public barOptions = {
        mainAspectRatio: false,
        legend: {
            display: true,
            position: "left"
        },

        scales: {
            xAxes: [
                {
                    scaleLabel: {
                        labelString: 'Time in Years',
                        display: true,
                    }
                }
            ],

            yAxes: [
                {
                    scaleLabel: {
                        labelString: '$ in Billions',
                        display: true,
                    },
                    ticks: {
                        beginAtZero: true
                    }
                }
            ]
        }
    };

    public lineData = {
        labels: ['Jan', 'Feb', 'Mar ', 'Apr ', 'May ', 'June ', 'July ', 'Aug ', 'Sep ', 'Oct ', 'Nov ', 'Dec '],

        datasets: [{
            label: "Expenditure",
            data: [110, 90, 120, 130, 100, 85, 100, 120, 125, 120, 125, 100],
            backgroundColor: '#e07f31',

        }]
    };

    public lineOptions = {
        mainAspectRatio: false,
        legend: {
            display: true,
            position: "left"
        },

        scales: {
            xAxes: [
                {
                    scaleLabel: {
                        labelString: 'Time in Years',
                        display: true,
                    }
                }
            ],

            yAxes: [
                {
                    scaleLabel: {
                        labelString: '$ in Billions',
                        display: true,
                    },
                    ticks: {
                        beginAtZero: true
                    }
                }
            ]
        }
    };

    public render(): React.ReactElement {
        return (
            <div className ="container">
            <div className="row">
                <div className="col-md-6 col-sm-12 p-md-0">
                    <div className="card d-flex shadow p-3 mt-3 " >
                        <div className="title mb-2 d-flex align-items-center">
                            <div className="d-flex rounded-circle circle-bg mr-2 justify-content-center align-items-center">
                                <img src={iconApproval} alt="approval" />
                            </div>
                            <div className="ml-2 ">
                                <h6 className="mb-1 font-weight-bold">Total bank Expenditure (In Bn)</h6>
                                <p>Overall Summary- Total bank expenditure</p>
                            </div>

                            <div className="d-flex rounded-circle circle-bg ml-auto justify-content-center align-items-center">
                                <img src={iconApproval} alt="approval" />
                            </div>
                        </div>
                        <div className="mb-2 d-sm-flex  flex-wrap align-items-center">
                            <div className="mr-lg-2"> 
                                <p>Date Range</p>
                                <DateRangePicker><input type="input" className="form-control" /></DateRangePicker>
                            </div>
                            <div className=" ml-0 p-0"> 
                                <p>Currency</p>
                                <select className="form-control dropDown-text">
                                    <option selected>INR</option>
                                    <option>option 1</option>
                                    <option>option 2</option>
                                    <option>option 3</option>
                                </select>
                            </div>
                        </div> 

                        <div className="mb-2 d-flex align-items-center" >
                            <div className="ml-2 p-2">
                                <p>Total Expenditure from 2017-2020</p>
                                <h6 className="font-weight-bold text-primary" >₹ 4761.04 Bn</h6>
                            </div>
                            <div className=" ml-auto p-2 ">
                                <p>vs 2017</p>
                                <h6 className="font-weight-bold text-success">35.76%</h6>
                            </div>
                        </div>
                        <div className="d-flex mr-2 justify-content-center align-items-center">
                            <Bar
                                data={this.barData}
                                options={this.barOptions}
                            />
                        </div>
                    </div>
                </div>

                <div className="col-lg-6 col-md-6 col-sm-12 ">
                    <div className="card d-flex shadow p-3 mt-3 ">
                        <div className="title mb-2 d-flex align-items-center">
                            <div className="d-flex rounded-circle circle-bg mr-2 justify-content-center align-items-center">
                                <img src={iconApproval} alt="approval" />
                            </div>
                            <div className="ml-2 ">
                                <h6 className="mb-1 font-weight-bold">Total bank Expenditure (In Bn)</h6>
                                <p>Overall Summary- Total bank expenditure</p>
                            </div>

                            <div className="d-flex rounded-circle circle-bg ml-auto justify-content-center align-items-center">
                                <img src={iconApproval} alt="approval" />
                            </div>
                        </div>
                        <div className="mb-2 d-sm-flex flex-wrap align-items-center">
                            <div className="mr-lg-2">
                                <p>Date Range</p>
                                <DateRangePicker><input type="input" className="form-control" /></DateRangePicker>
                            </div>
                            <div className=" ml-0 p-0"> 
                                <p>Currency</p>
                                <select className="form-control dropDown-text">
                                    <option selected>INR</option>
                                    <option>option 1</option>
                                    <option>option 2</option>
                                    <option>option 3</option>
                                </select>
                            </div>
                        </div>

                        <div className="mb-2 d-md-flex align-items-center" >
                            <div className="ml-2 p-2">
                                <p>Total Expenditure from Jan - Dec 2020</p>
                                <h6 className="font-weight-bold text-primary">₹  1385.61 Bn</h6>
                            </div>
                            <div className=" ml-auto p-2 ">
                                <p>vs 2019</p>
                                <h6 className="font-weight-bold text-success">10.3%</h6>
                            </div>
                        </div>

                        <div className="d-flex mr-2 justify-content-center align-items-center mt-2">
                            <Line
                                data={this.lineData}
                                options={this.lineOptions}
                            />
                        </div>
                    </div>
                </div>

            </div>
        </div>
        );

    }
}