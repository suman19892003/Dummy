import * as React from 'react';
export default class NewPage  extends React.Component {

    public render(): React.ReactElement {
    console.log('New page...!',this.props);
        return (
            <div className="center">
                <h6>Credit card</h6> 
            </div>
        );

    }
}