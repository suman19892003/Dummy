declare interface IUniverse2DesignWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'Universe2DesignWebPartStrings' {
  const strings: IUniverse2DesignWebPartStrings;
  export = strings;
}
