import * as React from 'react';
import { IUniverse2DesignProps } from './IUniverse2DesignProps';
import "./universeStyle.css";
import './styles/Navbar.css';
import "./styles/style.css";
export default class Home extends React.Component<IUniverse2DesignProps, {}> {
    componentDidMount(): void;
    render(): React.ReactElement<IUniverse2DesignProps>;
}
//# sourceMappingURL=Home.d.ts.map