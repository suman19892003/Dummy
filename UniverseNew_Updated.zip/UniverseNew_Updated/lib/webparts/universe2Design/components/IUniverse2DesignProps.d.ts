export interface IUniverse2DesignProps {
    description: string;
}
//# sourceMappingURL=IUniverse2DesignProps.d.ts.map