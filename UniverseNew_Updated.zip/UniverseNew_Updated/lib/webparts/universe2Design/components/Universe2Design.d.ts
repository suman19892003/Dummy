import * as React from 'react';
import { IUniverse2DesignProps } from './IUniverse2DesignProps';
import './styles/style.css';
export default class Universe2Design extends React.Component<IUniverse2DesignProps, {}> {
    render(): React.ReactElement<IUniverse2DesignProps>;
}
//# sourceMappingURL=Universe2Design.d.ts.map