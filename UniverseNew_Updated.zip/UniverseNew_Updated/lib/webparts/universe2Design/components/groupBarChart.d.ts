import * as React from 'react';
import "./styles/style.css";
export default class GroupBarChart extends React.Component {
    data: {
        labels: string[];
        datasets: {
            label: string;
            data: number[];
            backgroundColor: string;
        }[];
    };
    options: {
        scales: {
            yAxes: {
                ticks: {
                    beginAtZero: boolean;
                };
            }[];
        };
    };
    render(): React.ReactElement;
}
//# sourceMappingURL=groupBarChart.d.ts.map