import * as React from 'react';
import "./styles/style.css";
export default class GroupChart extends React.Component {
    barData: {
        labels: number[];
        datasets: {
            label: string;
            data: number[];
            backgroundColor: string;
        }[];
    };
    barOptions: {
        mainAspectRatio: boolean;
        legend: {
            display: boolean;
            position: string;
        };
        scales: {
            xAxes: {
                scaleLabel: {
                    labelString: string;
                    display: boolean;
                };
            }[];
            yAxes: {
                scaleLabel: {
                    labelString: string;
                    display: boolean;
                };
                ticks: {
                    beginAtZero: boolean;
                };
            }[];
        };
    };
    lineData: {
        labels: string[];
        datasets: {
            label: string;
            data: number[];
            backgroundColor: string;
        }[];
    };
    lineOptions: {
        mainAspectRatio: boolean;
        legend: {
            display: boolean;
            position: string;
        };
        scales: {
            xAxes: {
                scaleLabel: {
                    labelString: string;
                    display: boolean;
                };
            }[];
            yAxes: {
                scaleLabel: {
                    labelString: string;
                    display: boolean;
                };
                ticks: {
                    beginAtZero: boolean;
                };
            }[];
        };
    };
    render(): React.ReactElement;
}
//# sourceMappingURL=groupChart.d.ts.map