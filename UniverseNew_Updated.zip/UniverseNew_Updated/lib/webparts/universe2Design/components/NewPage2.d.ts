import * as React from 'react';
export default class NewPage extends React.Component {
    render(): React.ReactElement;
}
//# sourceMappingURL=NewPage2.d.ts.map