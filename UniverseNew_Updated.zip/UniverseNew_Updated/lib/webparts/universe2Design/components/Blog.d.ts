import * as React from 'react';
export default class Blog extends React.Component {
    render(): React.ReactElement;
}
//# sourceMappingURL=Blog.d.ts.map