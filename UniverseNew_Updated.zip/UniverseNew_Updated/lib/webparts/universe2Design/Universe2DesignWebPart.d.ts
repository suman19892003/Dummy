import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import "../../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import '../../../node_modules/bootstrap/dist/js/bootstrap.min.js';
import '../../../node_modules/popper.js/dist/popper.js';
import '../../../node_modules/bootstrap-daterangepicker/daterangepicker.css';
export interface IUniverse2DesignWebPartProps {
    description: string;
}
export default class Universe2DesignWebPart extends BaseClientSideWebPart<IUniverse2DesignWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=Universe2DesignWebPart.d.ts.map